﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WSubastas
{
    public partial class fmrGestionSubastas : Form
    {
        public fmrGestionSubastas()
        {
            InitializeComponent();
        }



        private void nuevoToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            WSubasta frmsubasta = new WSubasta();
            frmsubasta.MdiParent = this;
            frmsubasta.Show();
        }

        private void subastasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form frmGestionSubasta = this.ActiveMdiChild;
            if (frmGestionSubasta != null)
            {
                frmGestionSubasta.Close();
            }
        }

        private void salirToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            this.Close();
        }


    }
}
