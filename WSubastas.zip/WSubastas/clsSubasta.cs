﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WSubastas
{
    internal class clsSubasta
    {
        public string Producto {  get; set; }
        public double PrecioInicial { get; set; }
        public int Duracion { get; set; }
        public string Reglas  { get; set; }

        public clsSubasta(string producto, double precioinicial, int duracion, string reglas)
        { 
            this.Producto = producto;
            this.PrecioInicial = precioinicial;
            this.Duracion = duracion;
            this.Reglas = reglas;
        }

         
        /*public string InformacionSubasta (string producto, double precioinicial, int duracion, string reglas)
        {  
            return $"La informacion de la subasta es: El Producto es: {producto}, el Precio Inicial es: {precioinicial}, La Duracion es: {duracion}, Las reglas son: {reglas}"; 
        }*/


    }
}
